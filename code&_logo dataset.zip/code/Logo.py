import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.applications import EfficientNetB3
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, GlobalAveragePooling2D
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.callbacks import ReduceLROnPlateau, EarlyStopping
from tensorflow.keras.optimizers import Adam
from sklearn.metrics import precision_recall_curve
from tensorflow.keras import mixed_precision
from tensorflow.data import AUTOTUNE  # Explicitly import AUTOTUNE

# Enable Mixed Precision for Faster Training
mixed_precision.set_global_policy('mixed_float16')

# **Set Dataset Paths**
DATASET_PATH1 = "/content/drive/MyDrive/Projects/Major_Project/python_files/Logo_dataset_first"
DATASET_PATH2 = "/content/drive/MyDrive/Projects/Major_Project_Final/A_Dataset"

TRAIN_DIR1 = os.path.join(DATASET_PATH1, "train2")
TRAIN_DIR2 = os.path.join(DATASET_PATH2, "train2")
VAL_DIR = os.path.join(DATASET_PATH2, "valid")
TEST_DIR = os.path.join(DATASET_PATH2, "test")

IMG_SIZE = (224, 224)
BATCH_SIZE = 16

# **Check GPU Availability**
def check_gpu():
    print("Num GPUs Available:", len(tf.config.list_physical_devices('GPU')))
check_gpu()

# **Data Augmentation & Preprocessing**
train_datagen = ImageDataGenerator(
    rescale=1.0/255,
    rotation_range=15,
    width_shift_range=0.1,
    height_shift_range=0.1,
    horizontal_flip=True)

val_test_datagen = ImageDataGenerator(rescale=1.0/255)

train_generator1 = train_datagen.flow_from_directory(
    TRAIN_DIR1, target_size=IMG_SIZE, batch_size=BATCH_SIZE, class_mode='binary')

train_generator2 = train_datagen.flow_from_directory(
    TRAIN_DIR2, target_size=IMG_SIZE, batch_size=BATCH_SIZE, class_mode='binary')

val_generator = val_test_datagen.flow_from_directory(
    VAL_DIR, target_size=IMG_SIZE, batch_size=BATCH_SIZE, class_mode='binary')

test_generator = val_test_datagen.flow_from_directory(
    TEST_DIR, target_size=IMG_SIZE, batch_size=BATCH_SIZE, class_mode='binary', shuffle=False)

# **Create tf.data Pipeline for Faster Training**
# Instead of creating datasets from single batches, use the generators directly
# and combine them using tf.data.Dataset.from_generator
def create_dataset(generator):
    return tf.data.Dataset.from_generator(
        lambda: generator,
        output_types=(tf.float32, tf.float32),
        output_shapes=(tf.TensorShape([None, 224, 224, 3]), tf.TensorShape([None]))
    )

# Instead of concatenating datasets and then batching, combine generators first
# and create a dataset from that combined generator
def combined_generator(gen1, gen2):
    while True:
        # Get a batch from each generator
        batch1 = next(gen1)
        batch2 = next(gen2)

        # Combine the batches
        images = np.concatenate([batch1[0], batch2[0]])
        labels = np.concatenate([batch1[1], batch2[1]])

        yield images, labels

combined_gen = combined_generator(train_generator1, train_generator2)
train_dataset = create_dataset(combined_gen).prefetch(AUTOTUNE)

# **Load EfficientNetB3 Model**
base_model = EfficientNetB3(weights="imagenet", include_top=False, input_shape=(224, 224, 3))

# **Unfreeze Last 50 Layers**
for layer in base_model.layers[-50:]:
    layer.trainable = True

# **Define Model**
model = Sequential([
    base_model,
    GlobalAveragePooling2D(),
    Dense(256, activation='relu'),
    Dropout(0.2),
    Dense(1, activation='sigmoid')
])

# **Compile Model**
model.compile(optimizer=Adam(learning_rate=5e-5),
              loss='binary_crossentropy',
              metrics=['accuracy', tf.keras.metrics.AUC()])

# **Callbacks**
callbacks = [
    ReduceLROnPlateau(monitor='val_loss', factor=0.2, patience=2, verbose=1),
    EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True, verbose=1)
]

# **Train Model**
model.fit(train_dataset,
          validation_data=val_generator,
          epochs=30,
          callbacks=callbacks)

# **Save Model**
model.save("/content/drive/MyDrive/Projects/Major_Project/python_files/Models/brand_logo_classifier_v5.keras")
print("Model training complete and saved!")