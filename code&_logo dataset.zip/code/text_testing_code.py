import numpy as np
import pandas as pd
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from paddleocr import PaddleOCR
import logging

# Set logging level to suppress debug messages
logging.getLogger("ppocr").setLevel(logging.INFO)

# Load trained model
cnn_model = load_model("/content/drive/MyDrive/Projects/Major_Project/python_files/Models/text_classification_model.keras")

# Initialize PaddleOCR
ocr = PaddleOCR(use_angle_cls=True, lang='en')

# Function to extract text using PaddleOCR
def extract_text_paddleocr(image_path):
    result = ocr.ocr(image_path, cls=True)
    extracted_text = " ".join([line[1][0] for line in result[0]]) if result[0] else ""
    return extracted_text

# Load dataset CSV for tokenizer
dataset_csv = "/content/drive/MyDrive/Projects/Major_Project/python_files/text_dataset/data/text_csv.csv"
data = pd.read_csv(dataset_csv)

# Tokenization setup
tokenizer = Tokenizer(num_words=5000)
tokenizer.fit_on_texts(data['text'].astype(str))

# Function to classify an input image
def classify_text(image_path):
    text = extract_text_paddleocr(image_path)
    print(f"Extracted Text: {text}")

    # Define known variants and their labels
    variants = {"bisleri": "Real", "bisferi": "Fake", "bishaka": "Fake"}

    for variant, label in variants.items():
        if variant in text.lower():
            print(f"Associated Label: {label}")
            return

    # Convert text to sequence for CNN prediction
    text_sequence = tokenizer.texts_to_sequences([text])
    text_padded = pad_sequences(text_sequence, maxlen=100)
    text_padded = text_padded.reshape(text_padded.shape[0], text_padded.shape[1], 1, 1)

    prediction = cnn_model.predict(text_padded)
    label = "Real" if prediction[0][0] > 0.5 else "Fake"
    print(f"Prediction: {label}\n")

# Test with an input image
test_images = [
    "/content/drive/MyDrive/Projects/Major_Project/python_files/text_dataset/test_images/Fake/#Bisleri_fake_002.jpg",
    "/content/drive/MyDrive/Projects/Major_Project/python_files/text_dataset/test_images/Fake/#Bisleri_fake_003.jpg",
    "/content/drive/MyDrive/Projects/Major_Project/python_files/text_dataset/test_images/Real/#Bisleri_real_001.jpg"
]

for img_path in test_images:
    classify_text(img_path)