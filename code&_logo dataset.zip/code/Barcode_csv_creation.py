import cv2
import os
import pandas as pd
from pyzbar.pyzbar import decode

# Define dataset root folder
dataset_root = "/content/drive/MyDrive/Projects/Major_Project/python_files/Barcode_dataset_gen"
csv_filename = os.path.join(dataset_root, "bar_codes.csv")

# Initialize list to store barcode data
data_list = []

# Loop through barcode folders
for category in ["real_barcodes", "fake_barcodes"]:
    folder_path = os.path.join(dataset_root, category)

    if not os.path.exists(folder_path):
        print(f"⚠️ Warning: Folder '{folder_path}' not found, skipping...")
        continue

    # Assign label: 1 = Real, 0 = Fake
    label = 1 if category == "real_barcodes" else 0

    # Loop through image files in the category folder
    for filename in os.listdir(folder_path):
        if filename.lower().endswith(('.png', '.jpg', '.jpeg')):  # Check for valid image files
            image_path = os.path.join(folder_path, filename)
            img = cv2.imread(image_path)
            detected_codes = decode(img)

            for code in detected_codes:
                code_data = code.data.decode('utf-8')  # Extract barcode value
                data_list.append([code_data, label])  # Append barcode data with label

# Convert data list to DataFrame
df = pd.DataFrame(data_list, columns=['code', 'label'])

# Save DataFrame to CSV
df.to_csv(csv_filename, index=False)

if not df.empty:
    print(f"✅ CSV file '{csv_filename}' created successfully with {len(df)} entries!")
else:
    print("❌ No barcode data found in images. Check your dataset.")

