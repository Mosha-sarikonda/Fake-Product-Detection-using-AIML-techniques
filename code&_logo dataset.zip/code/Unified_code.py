import os
import cv2
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from paddleocr import PaddleOCR
from pyzbar.pyzbar import decode

ocr = PaddleOCR(use_angle_cls=True, lang='en')

# Load pre-trained models
logo_model_path = "/content/drive/MyDrive/Projects/Major_Project/python_files/Models/logo_classification_model.keras"
barcode_csv_path = "/content/drive/MyDrive/Projects/Major_Project/python_files/Barcode_dataset_gen/bar_codes.csv"
text_csv_path = "/content/drive/MyDrive/Projects/Major_Project/python_files/text_dataset/data/text_csv.csv"

# Load text dataset
text_df = pd.read_csv(text_csv_path)
texts = text_df['text'].astype(str).tolist()
labels = text_df['label'].tolist()

# Tokenize text dataset
tokenizer = Tokenizer(num_words=5000)
tokenizer.fit_on_texts(texts)

# Load logo model
logo_model = load_model(logo_model_path)

# Load barcode dataset
barcode_df = pd.read_csv(barcode_csv_path)
barcode_dict = dict(zip(barcode_df['barcode'], barcode_df['label']))

# Function to extract text using OCR
def extract_text_paddleocr(image_path):
    result = ocr.ocr(image_path, cls=True)
    extracted_text = " ".join([line[1][0] for line in result[0]]) if result[0] else ""
    return extracted_text

# Function to decode barcode
def decode_barcode(image_path):
    img = cv2.imread(image_path)
    if img is None:
        return ""
    barcodes = decode(img)
    return barcodes[0].data.decode('utf-8') if barcodes else ""

# Function to classify text-based features
def classify_text(image_path):
    text = extract_text_paddleocr(image_path)
    text_sequence = tokenizer.texts_to_sequences([text])
    text_padded = pad_sequences(text_sequence, maxlen=100)
    predicted_label = "Real" if 'Bisleri' in text else "Fake"
    return predicted_label

# Function to classify logo
def classify_logo(image_path):
    img = cv2.imread(image_path)
    if img is None:
        return "Fake"
    img = cv2.resize(img, (128, 128))
    img = img / 255.0
    img = np.expand_dims(img, axis=0)
    prediction = logo_model.predict(img)
    prediction = logo_model.predict(img)
    print(f"Prediction score: {prediction[0][0]}")

    return "Real" if prediction[0][0] > 0.8 else "Fake"  # Adjusted threshold to 0.7 for better accuracy

# Function to classify barcode
def classify_barcode(image_path):
    barcode_data = decode_barcode(image_path)
    return "Real" if barcode_dict.get(barcode_data, 0) == 1 else "Fake"

# Unified function to classify an image
def classify_image(image_path):
    text_result = classify_text(image_path)
    logo_result = classify_logo(image_path)
    barcode_result = classify_barcode(image_path)

    results = {"Text": text_result, "Logo": logo_result, "Barcode": barcode_result}

    final_decision = "Real" if list(results.values()).count("Real") > 1 else "Fake"
    return results, final_decision

# Example usage
image_path = "/content/drive/MyDrive/Projects/Major_Project/python_files/Logo_dataset_first/test/Real/real_adidas_010.jpg"
results, decision = classify_image(image_path)
print(f"Classification Results: {results}")
print(f"Final Decision: {decision}")
