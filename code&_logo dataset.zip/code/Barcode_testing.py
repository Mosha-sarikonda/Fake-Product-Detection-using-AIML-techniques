import cv2
import numpy as np
from pyzbar.pyzbar import decode
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import accuracy_score
import joblib
import os
from google.colab.patches import cv2_imshow

# Load genuine product dataset
csv_filename = "/content/drive/MyDrive/Projects/Major_Project/python_files/Barcode_dataset_gen/bar_codes.csv"
genuine_codes = pd.read_csv(csv_filename)  # Contains 'code' and 'label' columns

# Apply TF-IDF vectorization
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(genuine_codes['code'].astype(str))  # Convert barcode data into features
y = genuine_codes['label'].values  # 1 = real, 0 = fake

# Train the model
def train_model():
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = RandomForestClassifier(n_estimators=300, max_depth=20, random_state=42)
    model.fit(X_train, y_train)

    # Evaluate accuracy
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    print(f"✅ Model Accuracy: {accuracy * 100:.2f}%")

    # Save model and vectorizer
    joblib.dump(model, 'barcode_model.pkl')
    joblib.dump(vectorizer, 'tfidf_vectorizer.pkl')
    print("✅ Model trained and saved.")

# Function to scan and classify barcode
def scan_code(image_path):
    if not os.path.exists(image_path):
        print(f"❌ Error: Image file '{image_path}' not found.")
        return

    img = cv2.imread(image_path)
    detected_codes = decode(img)

    # Load trained model and vectorizer
    model = joblib.load('barcode_model.pkl')
    vectorizer = joblib.load('tfidf_vectorizer.pkl')

    if not detected_codes:
        print(f"⚠️ No barcodes detected in '{image_path}'.")
        return

    for code in detected_codes:
        code_data = code.data.decode('utf-8')
        print(f"🔍 Scanned Code: {code_data}")

        # Transform barcode using TF-IDF
        encoded_code = vectorizer.transform([code_data])

        # Predict authenticity
        prediction = model.predict(encoded_code)
        if prediction[0] == 1:
            print("✅ Genuine Product")
        else:
            print("❌ Fake Product")

        # Draw rectangle around detected barcode
        pts = np.array([code.polygon], np.int32).reshape((-1, 1, 2))
        cv2.polylines(img, [pts], True, (0, 255, 0), 2)

    cv2_imshow(img)

if __name__ == "__main__":
    train_model()
    scan_code("/content/drive/MyDrive/Projects/Major_Project/python_files/Barcode_dataset_gen/test_barcodes/test_real_1.png")  # Example test
