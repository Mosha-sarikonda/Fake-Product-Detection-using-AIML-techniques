import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import load_img, img_to_array
import os

# Load trained model
model_path = "/content/drive/MyDrive/Projects/Major_Project/python_files/Models/logo_classification_model.keras"
model = tf.keras.models.load_model(model_path)

# Define image size
img_size = (128, 128)

# Class labels (Real or Fake)
class_labels = ["Fake", "Real"]

def classify_logo(image_path):
    # Load and preprocess image
    img = load_img(image_path, target_size=img_size)
    img_array = img_to_array(img) / 255.0  # Normalize
    img_array = np.expand_dims(img_array, axis=0)  # Add batch dimension

    # Predict
    prediction = model.predict(img_array)
    class_index = np.argmax(prediction)
    predicted_class = class_labels[class_index]
    confidence = prediction[0][class_index] * 100

    print(f"Image: {os.path.basename(image_path)} -> Predicted: {predicted_class} ({confidence:.2f}%)")

# Example usage
test_images = [
    "/content/drive/MyDrive/Projects/Major_Project/python_files/Logo_dataset_first/test/Real/real_adidas_007.jpg",
    "/content/drive/MyDrive/Projects/Major_Project/python_files/Logo_dataset_first/test/Real/real_Bisleri_logo_143.jpg",
    "/content/drive/MyDrive/Projects/Major_Project/python_files/Logo_dataset_first/test/Fake/fake_Bisleri_logo_148.jpg",
    "/content/drive/MyDrive/Projects/Major_Project/python_files/Logo_dataset_first/test/Fake/fake_puma_026.jpg"
]

for img_path in test_images:
    classify_logo(img_path)
