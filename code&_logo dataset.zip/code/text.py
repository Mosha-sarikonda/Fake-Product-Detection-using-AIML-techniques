import os
import cv2
import numpy as np
import pandas as pd
from paddleocr import PaddleOCR
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from sklearn.model_selection import train_test_split
import logging

# Set logging level to suppress debug messages
logging.getLogger("ppocr").setLevel(logging.INFO)

# Initialize PaddleOCR
ocr = PaddleOCR(use_angle_cls=True, lang='en')

# Function to extract text using PaddleOCR
def extract_text_paddleocr(image_path):
    result = ocr.ocr(image_path, cls=True)
    extracted_text = " ".join([line[1][0] for line in result[0]]) if result[0] else ""
    return extracted_text

# Function to collect all image paths from multiple subfolders
def get_all_image_paths(root_folder):
    image_paths = []
    for root, _, files in os.walk(root_folder):
        for file in files:
            if file.lower().endswith((".png", ".jpg", ".jpeg")):
                image_paths.append(os.path.join(root, file))
    return image_paths

# Process dataset and create CSV
def create_dataset_csv(root_folder, output_csv):
    image_paths = get_all_image_paths(root_folder)
    data = []

    for img_path in image_paths:
        text = extract_text_paddleocr(img_path)
        label = 1 if "real" in img_path.lower() else 0  # Folder name indicates real/fake
        data.append([img_path, text, label])

    df = pd.DataFrame(data, columns=["image_path", "text", "label"])
    df.to_csv(output_csv, index=False)
    print(f"Dataset saved at {output_csv}")

# Define dataset path
dataset_root = "/content/drive/MyDrive/Projects/Major_Project/python_files/text_dataset/data"
dataset_csv = "/content/drive/MyDrive/Projects/Major_Project/python_files/text_dataset/data/text_csv.csv"

# Create dataset CSV
create_dataset_csv(dataset_root, dataset_csv)

# Load dataset
data = pd.read_csv(dataset_csv)

# Text tokenization
tokenizer = Tokenizer(num_words=5000)
tokenizer.fit_on_texts(data['text'].astype(str))
X = tokenizer.texts_to_sequences(data['text'].astype(str))
X = pad_sequences(X, maxlen=100)
y = data['label'].values

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Reshape for CNN input
X_train = X_train.reshape(X_train.shape[0], X_train.shape[1], 1, 1)
X_test = X_test.reshape(X_test.shape[0], X_test.shape[1], 1, 1)

# Build CNN model
def create_cnn_model(input_length):
    model = Sequential([
        Conv2D(32, (3, 1), activation='relu', input_shape=(input_length, 1, 1)),
        MaxPooling2D((2, 1)),
        Conv2D(64, (3, 1), activation='relu'),
        MaxPooling2D((2, 1)),
        Flatten(),
        Dense(128, activation='relu'),
        Dropout(0.5),
        Dense(1, activation='sigmoid')  # Binary Classification (Fake or Real)
    ])
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    return model

# Create and train the CNN model
cnn_model = create_cnn_model(X_train.shape[1])
cnn_model.fit(X_train, y_train, epochs=10, batch_size=32, validation_split=0.1)

# Save the trained model
cnn_model.save("/content/drive/MyDrive/Projects/Major_Project/python_files/Models/text_classification_model.keras")
